import { test, expect } from 'playwright/test';
import { createServer, type Server } from 'node:http';
import { readFileSync, mkdirSync, writeFileSync, existsSync } from 'node:fs';
import path from 'node:path';

type HandoffScenario = {
  scenario_id: string;
  case_id: string;
  first_tab_agent: string;
  second_tab_agent: string;
  takeover_banner: string;
  previous_tab_locked: 'yes' | 'no';
  websocket_event: string;
  typed_draft: string;
};

type OfflineScenario = {
  check_id: string;
  trigger: string;
  expected_banner: string;
  expected_navigator_online: 'yes' | 'no';
  expected_composer_enabled: 'yes' | 'no';
  expected_send_enabled: 'yes' | 'no';
};

const root = process.cwd();
const handoffs = JSON.parse(readFileSync(path.join(root, 'handoff_scenarios.json'), 'utf8')) as HandoffScenario[];
const offlineContract = JSON.parse(readFileSync(path.join(root, 'offline_scenarios.json'), 'utf8')) as OfflineScenario[];
const sessions = JSON.parse(readFileSync(path.join(root, 'fixtures/sessions.json'), 'utf8')) as Array<{ case_id: string }>;
const outputDir = path.resolve(root, '..', 'output');
const reportDir = path.join(outputDir, 'reports');

let server: Server;
let baseURL = '';
let browserContextCount = 0;
let browserPageCount = 0;
let externalRequestCount = 0;
const handoffRows: unknown[][] = [];
const draftRows: unknown[][] = [];
const offlineRows: unknown[][] = [];
const executablePath = [
  process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE,
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/usr/bin/google-chrome',
  '/usr/bin/chromium',
].find((candidate): candidate is string => Boolean(candidate && existsSync(candidate)));

function csvCell(value: unknown): string {
  const text = String(value ?? '');
  return /[",\n\r]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

function writeReport(directory: string, fileName: string, content: string): void {
  writeFileSync(path.join(directory, fileName), content);
}

function writeCsv(directory: string, fileName: string, header: string[], rows: unknown[][]): void {
  writeReport(directory, fileName, `${[header, ...rows].map((row) => row.map(csvCell).join(',')).join('\n')}\n`);
}

function byTrigger(trigger: string): OfflineScenario {
  const item = offlineContract.find((candidate) => candidate.trigger === trigger);
  if (!item) throw new Error(`offline trigger missing: ${trigger}`);
  return item;
}

async function observeOffline(page: any, contract: OfflineScenario, expectedDraft: string): Promise<void> {
  await expect(page.getByTestId('banner')).toHaveText(contract.expected_banner);
  const observed = await page.evaluate(() => ({
    banner: document.querySelector('[data-testid=banner]')?.textContent ?? '',
    navigatorOnline: navigator.onLine ? 'yes' : 'no',
    composerEnabled: (document.querySelector('[data-testid=composer]') as HTMLTextAreaElement).disabled ? 'no' : 'yes',
    sendEnabled: (document.querySelector('[data-testid=send-reply]') as HTMLButtonElement).disabled ? 'no' : 'yes',
    draft: (document.querySelector('[data-testid=composer]') as HTMLTextAreaElement).value,
  }));
  expect(observed.navigatorOnline).toBe(contract.expected_navigator_online);
  expect(observed.composerEnabled).toBe(contract.expected_composer_enabled);
  expect(observed.sendEnabled).toBe(contract.expected_send_enabled);
  expect(observed.draft).toBe(expectedDraft);
  offlineRows.push([
    contract.check_id,
    contract.trigger,
    contract.expected_banner,
    observed.banner,
    observed.navigatorOnline,
    observed.composerEnabled,
    observed.sendEnabled,
    observed.draft === expectedDraft ? 'yes' : 'no',
  ]);
}

test.describe.configure({ mode: 'serial' });
if (executablePath) test.use({ launchOptions: { executablePath } });

test.beforeAll(async () => {
  mkdirSync(reportDir, { recursive: true });
  const scenarioIds = handoffs.map((item) => item.scenario_id);
  const checkIds = offlineContract.map((item) => item.check_id);
  if (new Set(scenarioIds).size !== scenarioIds.length) throw new Error('scenario_id must be unique');
  if (new Set(checkIds).size !== checkIds.length) throw new Error('check_id must be unique');
  if (new Set(sessions.map((item) => item.case_id)).size !== sessions.length) throw new Error('session case_id must be unique');
  const knownCases = new Set(sessions.map((item) => item.case_id));
  for (const scenario of handoffs) {
    if (!knownCases.has(scenario.case_id)) throw new Error(`unknown case_id: ${scenario.case_id}`);
    if (!['yes', 'no'].includes(scenario.previous_tab_locked)) throw new Error(`invalid lock contract: ${scenario.scenario_id}`);
    if (!scenario.typed_draft) throw new Error(`typed_draft missing: ${scenario.scenario_id}`);
  }
  const supportedTriggers = new Set(['browser_context_offline', 'socket_disconnected', 'network_restored', 'queued_send_retry']);
  for (const item of offlineContract) if (!supportedTriggers.has(item.trigger)) throw new Error(`unsupported offline trigger: ${item.trigger}`);

  server = createServer((request, response) => {
    const pathname = new URL(request.url ?? '/', 'http://fixture.test').pathname;
    const files: Record<string, [string, string]> = {
      '/': ['app/console.html', 'text/html; charset=utf-8'],
      '/console.html': ['app/console.html', 'text/html; charset=utf-8'],
      '/console.js': ['app/console.js', 'text/javascript; charset=utf-8'],
      '/fixtures/sessions.json': ['fixtures/sessions.json', 'application/json; charset=utf-8'],
    };
    const match = files[pathname];
    if (!match) { response.writeHead(404).end('not found'); return; }
    response.setHeader('content-type', match[1]);
    response.end(readFileSync(path.join(root, match[0])));
  });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  const address = server.address();
  if (!address || typeof address === 'string') throw new Error('fixture server did not bind');
  baseURL = `http://127.0.0.1:${address.port}`;
});

for (const scenario of handoffs) {
  test(`observes cross-tab handoff ${scenario.scenario_id}`, async ({ browser }) => {
    const context = await browser.newContext();
    browserContextCount += 1;
    context.on('request', (request) => {
      const url = new URL(request.url());
      if (url.protocol.startsWith('http') && url.hostname !== '127.0.0.1') externalRequestCount += 1;
    });
    const first = await context.newPage();
    const second = await context.newPage();
    browserPageCount += 2;
    await first.goto(`${baseURL}/console.html?agent=${encodeURIComponent(scenario.first_tab_agent)}&case=${encodeURIComponent(scenario.case_id)}`);
    await first.getByTestId('composer').fill(scenario.typed_draft);
    await first.reload();
    await expect(first.getByTestId('composer')).toHaveValue(scenario.typed_draft);
    await second.goto(`${baseURL}/console.html?agent=${encodeURIComponent(scenario.second_tab_agent)}&case=${encodeURIComponent(scenario.case_id)}`);
    await second.evaluate((payload) => {
      (window as any).__publishHandoff(payload.caseId, payload.nextAgent, payload.eventName, payload.banner);
    }, { caseId: scenario.case_id, nextAgent: scenario.second_tab_agent, eventName: scenario.websocket_event, banner: scenario.takeover_banner });
    await expect(first.getByTestId('banner')).toHaveText(scenario.takeover_banner);
    await expect(first.locator('body')).toHaveAttribute('data-last-handoff-event', scenario.websocket_event);
    const observedLocked = await first.getByTestId('send-reply').isDisabled() ? 'yes' : 'no';
    expect(observedLocked).toBe(scenario.previous_tab_locked);
    const sendOutcome = observedLocked === 'yes' ? 'blocked' : 'allowed';
    if (sendOutcome === 'allowed') {
      await first.getByTestId('send-reply').click();
      await expect(first.getByTestId('banner')).toHaveText('Reply sent');
    }
    handoffRows.push([
      scenario.scenario_id, scenario.case_id, scenario.first_tab_agent, scenario.second_tab_agent,
      scenario.websocket_event, scenario.takeover_banner, scenario.takeover_banner, scenario.previous_tab_locked, observedLocked,
    ]);
    draftRows.push([
      scenario.scenario_id, scenario.case_id, `draft:${scenario.case_id}`, scenario.typed_draft,
      await first.getByTestId('composer').inputValue(), sendOutcome,
    ]);
    await context.close();
  });
}

test('observes offline, reconnecting, restored and queued-delivery states', async ({ browser }) => {
  const context = await browser.newContext();
  browserContextCount += 1;
  const page = await context.newPage();
  browserPageCount += 1;
  const caseId = sessions[0].case_id;
  const draft = '网络恢复后继续回复';
  await page.goto(`${baseURL}/console.html?agent=agent-a&case=${encodeURIComponent(caseId)}`);
  await page.getByTestId('composer').fill(draft);

  await context.setOffline(true);
  await observeOffline(page, byTrigger('browser_context_offline'), draft);
  await page.evaluate(() => (window as any).__socketState('disconnected'));
  await observeOffline(page, byTrigger('socket_disconnected'), draft);
  await context.setOffline(false);
  await observeOffline(page, byTrigger('network_restored'), draft);
  await page.evaluate(() => (window as any).__socketState('queued_delivered'));
  await observeOffline(page, byTrigger('queued_send_retry'), draft);
  await context.close();
});

test.afterAll(async () => {
  await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
  expect(handoffRows.length).toBe(handoffs.length);
  expect(draftRows.length).toBe(handoffs.length);
  expect(offlineRows.length).toBe(offlineContract.length);
  expect(browserContextCount).toBe(handoffs.length + 1);
  expect(browserPageCount).toBe(handoffs.length * 2 + 1);
  expect(externalRequestCount).toBe(0);
  writeCsv(reportDir, 'handoff_state_matrix.csv', [
      'scenario_id', 'case_id', 'first_tab_agent', 'second_tab_agent', 'websocket_event',
      'expected_banner', 'observed_banner', 'expected_previous_tab_locked', 'observed_previous_tab_locked',
    ], handoffRows);
  writeCsv(reportDir, 'draft_recovery_report.csv', [
      'scenario_id', 'case_id', 'draft_key', 'typed_before_reload', 'restored_after_reload', 'send_outcome_after_handoff',
    ], draftRows);
  writeCsv(reportDir, 'offline_banner_checks.csv', [
      'check_id', 'trigger', 'expected_banner', 'observed_banner', 'navigator_online',
      'composer_enabled', 'send_enabled', 'draft_preserved',
    ], offlineRows);
});
