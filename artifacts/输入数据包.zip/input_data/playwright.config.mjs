export default {
  testDir: '../output/tests',
  timeout: 30000,
  fullyParallel: false,
  workers: 1,
  reporter: 'line',
  outputDir: '../output/.playwright-results',
};
