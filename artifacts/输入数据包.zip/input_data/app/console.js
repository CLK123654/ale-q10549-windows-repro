const sessions = await fetch('/fixtures/sessions.json').then((response) => {
  if (!response.ok) throw new Error(`sessions fixture failed: ${response.status}`);
  return response.json();
});

const params = new URLSearchParams(location.search);
const agent = params.get('agent') || 'agent-a';
let active = params.get('case') || sessions[0]?.case_id;
let locked = false;
let socketConnected = true;

const agentNode = document.querySelector('[data-testid=agent]');
const bannerNode = document.querySelector('[data-testid=banner]');
const composerNode = document.querySelector('[data-testid=composer]');
const sendNode = document.querySelector('[data-testid=send-reply]');

agentNode.textContent = agent;

function draftKey() {
  return `draft:${active}`;
}

function updateInteractivity() {
  document.body.classList.toggle('locked', locked);
  document.body.dataset.locked = locked ? 'yes' : 'no';
  sendNode.disabled = locked || !navigator.onLine || !socketConnected;
  composerNode.disabled = false;
}

function draw() {
  document.querySelector('#cases').innerHTML = sessions.map((session) =>
    `<button class="case" data-case="${session.case_id}">${session.case_id} ${session.customer}</button>`
  ).join('');
  composerNode.value = localStorage.getItem(draftKey()) || '';
  updateInteractivity();
}

window.addEventListener('storage', (event) => {
  if (event.key !== `handoff:${active}` || !event.newValue) return;
  const message = JSON.parse(event.newValue);
  locked = message.nextAgent !== agent;
  bannerNode.textContent = message.banner;
  document.body.dataset.lastHandoffEvent = message.eventName;
  document.body.dataset.lastHandoffAgent = message.nextAgent;
  updateInteractivity();
});

window.addEventListener('offline', () => {
  bannerNode.textContent = 'You are offline. Replies are saved as draft.';
  updateInteractivity();
});

window.addEventListener('online', () => {
  socketConnected = true;
  bannerNode.textContent = 'Back online. Draft preserved.';
  updateInteractivity();
});

document.addEventListener('click', (event) => {
  if (event.target.dataset.case) {
    active = event.target.dataset.case;
    locked = false;
    bannerNode.textContent = '';
    draw();
  }
});

composerNode.addEventListener('input', (event) => {
  localStorage.setItem(draftKey(), event.target.value);
});

sendNode.addEventListener('click', () => {
  bannerNode.textContent = 'Reply sent';
});

window.__publishHandoff = (caseId, nextAgent, eventName, banner) => {
  localStorage.setItem(`handoff:${caseId}`, JSON.stringify({
    caseId,
    nextAgent,
    eventName,
    banner,
    sequence: `${Date.now()}-${Math.random()}`,
  }));
};

window.__socketState = (state) => {
  if (state === 'disconnected') {
    socketConnected = false;
    bannerNode.textContent = 'Connection lost. Reconnecting…';
  } else if (state === 'queued_delivered') {
    socketConnected = true;
    bannerNode.textContent = 'Queued reply delivered';
  } else {
    throw new Error(`unsupported socket state: ${state}`);
  }
  updateInteractivity();
};

draw();
