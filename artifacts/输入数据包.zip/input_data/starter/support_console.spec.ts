import { test, expect } from 'playwright/test';

test('TODO: complete support handoff regression', async ({ browser }) => {
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto('/console.html?agent=agent-a&case=T-710');
  await expect(page.getByTestId('composer')).toBeVisible();
});
