import { createRequire } from 'node:module';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import fs from 'node:fs';

const require = createRequire(import.meta.url);
const cli = path.join(path.dirname(require.resolve('playwright')), 'cli.js');
const outputRoot = path.resolve(process.cwd(), '..', 'output');
const outputNodeModules = path.join(outputRoot, 'node_modules');
const inputNodeModules = path.join(process.cwd(), 'node_modules');
const resultDir = path.join(outputRoot, '.playwright-results');
fs.mkdirSync(outputRoot, { recursive: true });
fs.rmSync(outputNodeModules, { recursive: true, force: true });
fs.symlinkSync(inputNodeModules, outputNodeModules, process.platform === 'win32' ? 'junction' : 'dir');
const result = spawnSync(process.execPath, [cli, 'test', 'support_console.spec.ts', '--config=playwright.config.mjs', '--workers=1'], {
  cwd: process.cwd(),
  stdio: 'inherit',
  windowsHide: true,
});
fs.rmSync(outputNodeModules, { recursive: true, force: true });
fs.rmSync(resultDir, { recursive: true, force: true });
if (result.error) throw result.error;
process.exitCode = result.status ?? 1;
